1) Name and NetIDs
Eddie Richter 	- edwardrichter
Sam Gianelli	- samjgianelli
Diego Jimenez	- diegojimenez
Hugo Valdez		- hugovaldez

2) Xilinx Synthesis tool version
Vivado 2017.1: Compenents 
Vivado 2017.2: Circuits 

3) Target FPGA and speed grade
The FPGA we ran was the xc7a100tcsg324-1 which has a speed grade of -1.

4) Critical path calculation
We first hand drew the RTL schematic of every circuit. After the circuits were drawn correctly, we were able to write the delay of every component in the circuit. We were then able to go through all possible paths in order to calculate the critical path and the corresponding critical path delay.